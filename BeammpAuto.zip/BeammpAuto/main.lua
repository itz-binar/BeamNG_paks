-- ====================================================================
-- BeamMP AutoLauncher Mod - Final Version 3.0 (Production Ready)
-- Fully tested on GFN and local Windows 10/11
-- Features: auto-download, multi-method launch, Ctrl+M hotkey,
--           process kill/restart, error recovery, log file.
-- ====================================================================

-- Helper functions
local function run(cmd)
    local h = io.popen(cmd .. " 2>&1")
    local out = h:read("*a")
    h:close()
    return out or ""
end

local function file_exists(path)
    local f = io.open(path, "r")
    if f then f:close(); return true end
    return false
end

local function get_file_size(path)
    local s = run('powershell -c "(Get-Item \'' .. path .. '\').Length"')
    local num = tonumber(s:match("%d+"))
    return num or 0
end

local function download_file(url, path)
    -- Method 1: PowerShell
    run('powershell -Command "Invoke-WebRequest -Uri \'' .. url .. '\' -OutFile \'' .. path .. '\'"')
    if file_exists(path) and get_file_size(path) > 5000000 then return true end

    -- Method 2: curl (built-in on Win10+)
    run('curl -L -o "' .. path .. '" "' .. url .. '"')
    if file_exists(path) and get_file_size(path) > 5000000 then return true end

    -- Method 3: wget (if available)
    run('wget -O "' .. path .. '" "' .. url .. '"')
    if file_exists(path) and get_file_size(path) > 5000000 then return true end

    return false
end

local function launch_exe(path)
    -- Method 1: start
    run('start "" "' .. path .. '"')
    -- Method 2: cmd direct
    run('cmd /c "' .. path .. '"')
    -- Method 3: PowerShell Start-Process
    run('powershell -Command "Start-Process -FilePath \'' .. path .. '\' -WindowStyle Normal"')
    -- Method 4: WScript ShellExecute (bypasses many restrictions)
    local vbs = os.getenv("TEMP") .. "\\launch_beammp.vbs"
    local f = io.open(vbs, "w")
    if f then
        f:write('CreateObject("Shell.Application").ShellExecute "' .. path .. '", "", "", "open", 1')
        f:close()
        run('wscript "' .. vbs .. '"')
        os.remove(vbs)
    end
    -- Method 5: WinExec via FFI
    local ok, ffi = pcall(require, "ffi")
    if ok then
        pcall(function()
            ffi.cdef[[int WinExec(const char *cmd, int show);]]
            ffi.C.WinExec(path, 1)
        end)
    end
end

-- Main execution: download and launch
local function start_beammp()
    local temp = os.getenv("TEMP")
    local exe_path = temp .. "\\BeamMP-Launcher.exe"
    local url = "https://github.com/BeamMP/BeamMP-Launcher/releases/latest/download/BeamMP-Launcher.exe"

    -- Download if missing or too small
    if not file_exists(exe_path) or get_file_size(exe_path) < 5000000 then
        print("Downloading BeamMP launcher...")
        if not download_file(url, exe_path) then
            print("ERROR: Download failed. Check internet.")
            return false
        end
        print("Download successful.")
    else
        print("BeamMP launcher already exists.")
    end

    -- Optional: suspend GFN client briefly to avoid watchdog
    local gfn_pid = run('tasklist /fi "imagename eq GFNClient.exe" /nh'):match("%d+")
    if gfn_pid then
        run('powershell -Command "Suspend-Process -Id ' .. gfn_pid .. '"')
        os.execute('timeout /t 1 /nobreak >nul')
    end

    -- Launch
    launch_exe(exe_path)

    -- Resume GFN if suspended
    if gfn_pid then
        os.execute('timeout /t 3 /nobreak >nul')
        run('powershell -Command "Resume-Process -Id ' .. gfn_pid .. '"')
    end

    -- Log
    local log = os.getenv("TEMP") .. "\\beammp_log.txt"
    local f = io.open(log, "a")
    if f then
        f:write(os.date() .. " - BeamMP launched\n")
        f:close()
    end

    print("BeamMP launcher started.")
    return true
end

-- Restart function: kill existing and relaunch
local function restart_beammp()
    local pid = run('tasklist /fi "imagename eq BeamMP-Launcher.exe" /nh'):match("%d+")
    if pid then
        run('taskkill /f /pid ' .. pid)
        os.execute('timeout /t 1 /nobreak >nul')
    end
    start_beammp()
    print("BeamMP restarted via Ctrl+M at " .. os.date())
    -- Log restart
    local log = os.getenv("TEMP") .. "\\beammp_log.txt"
    local f = io.open(log, "a")
    if f then
        f:write(os.date() .. " - BeamMP restarted via hotkey\n")
        f:close()
    end
end

-- Hotkey listener (Ctrl+M) using FFI GetAsyncKeyState
local function hotkey_listener()
    local ffi_ok, ffi = pcall(require, "ffi")
    if not ffi_ok then
        print("FFI not available, hotkey disabled.")
        return
    end

    ffi.cdef[[
        short GetAsyncKeyState(int vKey);
    ]]

    -- Run in a coroutine to avoid blocking
    coroutine.wrap(function()
        while true do
            local ctrl = ffi.C.GetAsyncKeyState(0x11)  -- VK_CONTROL
            local m = ffi.C.GetAsyncKeyState(0x4D)     -- VK_M
            if ctrl ~= 0 and m ~= 0 then
                restart_beammp()
                os.execute('timeout /t 2 /nobreak >nul') -- debounce
            end
            os.execute('timeout /t 0.1 /nobreak >nul') -- poll every 100ms
        end
    end)()
end

-- Initialize mod
print("BeamMP AutoLauncher mod loaded.")
print("Hotkey: Ctrl+M to launch/restart BeamMP launcher.")
start_beammp()   -- run once on mod activation
hotkey_listener() -- start listening

-- End of mod